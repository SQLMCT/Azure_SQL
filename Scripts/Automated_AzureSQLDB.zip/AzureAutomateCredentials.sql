--Create Login for jdAutomate in Master Database

CREATE LOGIN jdAutomate
    WITH PASSWORD = 'Indiana@123' 
GO

--Create User Account in jdsqldb

CREATE USER myazureautomation
FROM LOGIN jdAutomate
 
ALTER ROLE db_owner 
ADD MEMBER myazureautomation ;  
GO